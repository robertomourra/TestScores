//************************************  PROGRAM IDENTIFICATION  ***************************************
//*                                                                                                   *
//*   PROGRAM FILE NAME:  Project3.cpp          ASSIGNMENT #: 3            Grade: _________           *
//*                                                                                                   *
//*   PROGRAM AUTHOR:             Roberto Mourra                                                      *
//*                                                                                                   *
//*                   ___________________________________________________                             *
//*                                                                                                   *
//*   COURSE #:  CSC 24400 11                              DUE DATE: October 25 2019                  *
//*                                                                                                   *
//*****************************************************************************************************
//***********************************  PROGRAM DESCRIPTION  *******************************************
//*                                                                                                   *
//* PROCESS: This program is designed to print out different test scores with each student id's and   *
//* the average test scores.                                                                          *
//*****************************************************************************************************

#include <iostream>
#include <string>
#include <iomanip>
#include <math.h>
#include <fstream>

using namespace std;
void read(ifstream &,int [],float[][4],int &,float []); // prototype to read data
void printsimple(ofstream &,int [],float[][4],int &, float []); // prototype to printsimple
void printid(ofstream &, int[], float[][4], int &, float []); // prototype to print id
void printgrade(ofstream &, int[], float[][4], int &, float [],char []); // prototype print grade
void printtest(ofstream &, int[], float[][4], int &, float [],char []); // prototype to print test

// main body
int main() {

    ifstream infile("DATA3.txt",ios::in); // reads the data file
    ofstream out("out.txt",ios::out); // outputs the data in a new file

    int count = 0; // int varibale starting in 0.
    int record[50]; // int string with a total of 50 spaces.
    float score[50][4]; // two dimensional float array with 50 columns and 4 rows.
    float average[50]; // float array with 50 spaces.
    char gra[50]; // char array with 50 spaces.
    
    read(infile,record,score,count,average); // reads the infile numbers and know which is what.
    printsimple(out,record,score,count,average); // prints it out as count, average, score, etc.
    printid(out,record, score, count,average); // prints it out as count, average, score, etc.
    printgrade(out,record, score, count,average,gra); // prints it out as count, average, score, etc.
    printtest(out,record,score, count,average,gra); // prints it out as count, average, score, etc.

    return 0; // returns 0.
}

void read(ifstream &infile, int record[50], float score[][4], int &count,float average[50]) {

    int x = 0; // x is equal to 0 at start.
    float z1 = 0.0; // z1 is equal to 0 at start.
    float z2 = 0.0; // z2 is equal to 0 at start.
    float z3 = 0.0; // z3 is equal to 0 at start.
    float z4 = 0.0; // z4 is equal to 0 at start.


    while (x >= 0) // while x is greater than or equal to 0, do the following.
    {
        infile >> x >> z1 >> z2 >> z3 >> z4; // read the infile as x, z1,z2,z3,z4.

        if (x < 0) // if condition when x is less than 0.
        {
            return; // exits the condition because is N/A.
        }

        record[count] = x; // records the counts in x.
        score[count][0] = z1; // score count store in  z0.
        score[count][1] = z2; // score count store in  z1.
        score[count][2] = z3; // score count store in  z2.
        score[count][3] = z4; // score count store in  z3.
        count++; // adds 1 to count.
        average[count] = ((z1+z2+z3+z4)/4); // average is found by adding all together and dividing by the number of counts.
        }
}

// the printing method. There is a for loop top keep updating the number of counts depending on the student's id.
void printsimple(ofstream &out, int record[50], float score[][4], int &count,float average[50])
{
    out << "The original student data is: " << endl;
    out << "Student ID      Test 1    Test 2    Test 3    Test 4" << endl;
    out << "------------     ------    ------   ------    ------" << endl;
    for (int i = 0; i < count; i++) {
        out << record[i] << "             " << score[i][0] << "       " << score[i][1] << "      " << score[i][2] << "     " << score[i][3] << endl;
    }
    out << endl; // exits the loop and prints a blank line.

}
// prints the number of id for each individual student. Also it sorts them from high to low.
void printid(ofstream &out, int record[50], float score[][4], int &count,float average[50]) {
    out << "The list of students sorted by ID number high to low is: " << endl;
    out << "Student ID      Test 1    Test 2    Test 3    Test 4" << endl;
    out << "------------     ------    ------   ------    ------" << endl;

    // for loop's that sorts the outputs of the test grades and student ids.
    for (int i = 0; i <= count; i++) {
        for (int s = 0; s < count; s++) {
            
            if (record[s] < record[s + 1]) {

                int q; // integer variable
                float t, y, u, i; // float variables
                float iii; // float variable
                q = record[s];
                record[s] = record[s + 1];
                record[s + 1] = q;

                // t is stored at a specific row and column in the array.
                t = score[s][0];
                score[s][0] = score[s + 1][0];
                score[s + 1][0] = t;

                // y is stored at a specific row and column in the array.
                y = score[s][1];
                score[s][1] = score[s + 1][1];
                score[s + 1][1] = y;
                
                // u is stored at a specific row and column in the array.
                u = score[s][2];
                score[s][2] = score[s + 1][2];
                score[s + 1][2] = u;

                // i is stored at a specific row and column in the array.
                i = score[s][3];
                score[s][3] = score[s + 1][3];
                score[s + 1][3] = i;

                // iii is stored at a specific row and column in the array.
                iii = average[s];
                average[s] = average[s + 1];
                average[s + 1] = iii;

            }
        }
    }
    for (int i = 0; i < count; i++) {
        out << record[i] << "             " << score[i][0] << "       " << score[i][1] << "      " << score[i][2] << "      " << score[i][3] << endl;
    }
    out << endl;

}

void printgrade(ofstream &out,int record[50],float score[][4],int &count,float average[50],char gra[50]) {
    out << "The list of students with their test average and course grade is: " << endl;
    out << "Student ID      Test 1    Test 2    Test 3    Test 4     Test Ave     Course Grade" << endl;
    out << "------------     ------    ------   ------    ------     ------        --------" << endl;

    for (int i = 0; i < count; i++) {
        if (average[i] > 90.0 && average[i] < 100.0) { // when the average is greater than 90 but less tan 100.

            gra[i] = 'A'; // student gets a grade A.
        }
        else if (average[i] > 80.0 && average[i] < 90.0) { // when the average is greater than 80 but less tan 90.

            gra[i] = 'B'; // student get a grade B
        }
        else if (average[i] > 70.0 && average[i] < 80.0) { // when the average is greater than 70 but less tan 80.

            gra[i] = 'C'; // students gets a grade C.
        }
        else if (average[i] > 60.0 && average[i] < 70.0) { // when the average is greater than 60 but less tan 70.

            gra[i] = 'D'; // student gets a grade D.
        }
        else {

            gra[i] = 'F'; // student gets a grade F.
        }

        out << record[i] << "             " << score[i][0] << "       " << score[i][1] << "    " << score[i][2] << "        " << score[i][3]
            <<"      "<<average[i]<<"           "<<gra[i]<< endl;
    }
    out << endl; // exits the loops and prints out a blank line at the end for spacing.
}


void printtest(ofstream &out,int record[50],float score[][4],int &count,float average[50],char gra[50]) {
    out << "The list of students sorted by test average high to low is: " << endl;
    out << "Student ID      Test 1    Test 2    Test 3    Test 4    Test Ave     Course grade" << endl;
    out << "------------     ------    ------   ------    ------     -------      -------" << endl;

   int x = 0;
        float z1, z2, z3, z4; // float variables
        float ave; //float average
        char aleph; // char variable for alpeh.
        for (int j = 0; j <= count; j++) { // for loops that sorts
            for (int g = 0; g < count; g++) { // for loops that sorts
                
                if (average[g] < average[g + 1])
                {
                    // x is stored at a specific row and column in the array.
                    x = record[g];
                    record[g] = record[g + 1];
                    record[g + 1] = x;
    
                    // z1 is stored at a specific row and column in the array.
                    z1 = score[g][0];
                    score[g][0] = score[g + 1][0];
                    score[g + 1][0] = z1;
    
                    // z2 is stored at a specific row and column in the array.
                    z2 = score[g][1];
                    score[g][1] = score[g + 1][1];
                    score[g + 1][1] = z2;
    
                    // z3 is stored at a specific row and column in the array.
                    z3 = score[g][2];
                    score[g][2] = score[g + 1][2];
                    score[g + 1][2] = z3;

                    // z4 is stored at a specific row and column in the array.
                    z4 = score[g][3];
                    score[g][3] = score[g + 1][3];
                    score[g + 1][3] = z4;
    
                    // the average is stored at a specific row and column in the array.
                    ave = average[g];
                    average[g] = average[g + 1];
                    average[g + 1] = ave;
    
                    // the aleph is stored at a specific row and column in the array.
                    aleph = gra[g];
                    gra[g] = gra[g + 1];
                    gra[g + 1] = aleph;
                }
    
            }
        }
    
    // the test sscores are all stored at a specific location and then outputed in the file with the corresponding spacing.
        for (int i = 0; i < count; i++) {
            out << record[i] << "             " << score[i][0] << "       " << score[i][1] << "     " << score[i][2] << "      " << score[i][3]
                << "       " << average[i] << "           " << gra[i] << endl;
        }
        out << endl; // blank line for neatness.
    }

void header( ofstream &outfile)
{
    // Receives – the output file
    // Task - Prints the output preamble
    // Returns - Nothing
    outfile << setw(30) << "Roberto Mourra";
    outfile << setw(17) << "CSC 24400";
    outfile << setw(15) << "Section 11" << endl;
    outfile << setw(30) << "Fall 2019";
    outfile << setw(20) << "Assignment # 3" << endl;
    outfile << setw(35) << "---------------------------------- - ";
    outfile << setw(35) << "---------------------------------- - " << endl << endl;
    return;
}
//************************************* END OF FUNCTION HEADER  ****************************************

void Footer( ofstream &outfile)
{
    // Receives – the output file
    // Task - Prints the output salutation
    // Returns - Nothing
    outfile << endl;
    outfile << setw(35) << "-------------------------------- - " << endl;
    outfile << setw(35) << "     | END OF PROGRAM OUTPUT |     " << endl;
    outfile << setw(35) << "-------------------------------- - " << endl;
    return;
}
//************************************* END OF FUNCTION FOOTER  ****************************************

